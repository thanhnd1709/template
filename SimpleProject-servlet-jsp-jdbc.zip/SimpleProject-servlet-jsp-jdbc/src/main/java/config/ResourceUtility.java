package config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ResourceUtility {
	public static ClassLoader classLoader;
	public static Properties properties;
	public static String getResource(String resourceName) {
		if (properties == null) {
			properties = new Properties();
			try {
				classLoader = Thread.currentThread().getContextClassLoader();
				InputStream input = classLoader.getResourceAsStream("applications.properties");
				properties.load(input);
				return properties.getProperty(resourceName);
			}  catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return properties.getProperty(resourceName);
		}	
	}

}
