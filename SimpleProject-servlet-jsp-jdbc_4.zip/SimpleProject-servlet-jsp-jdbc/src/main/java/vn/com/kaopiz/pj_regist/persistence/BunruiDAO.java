package vn.com.kaopiz.pj_regist.persistence;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.kaopiz.pj_regist.config.ConnectionFactory;
import vn.com.kaopiz.pj_regist.model.Bunrui;

public class BunruiDAO {
	
private Connection connection = ConnectionFactory.getConnection();
	
	public void register(Bunrui bunrui) throws SQLException{
		if(bunrui != null && bunrui.getId() != 0){
			update(bunrui);
		}else{
			insert(bunrui);
		}
	}

	/**
	 * Insert new bunrui
	 * @param bunrui
	 */
	private void insert(Bunrui bunrui) {
		
	}

	/**
	 * Modify existing bunrui
	 * @param bunrui
	 * @throws SQLException
	 */
	private void update(Bunrui bunrui) throws SQLException {
		
	}
	
	/**
	 * Deleting bunrui
	 * @param bunrui
	 * @throws SQLException
	 */
	public void delete(Bunrui bunrui) throws SQLException {
		
	}
	
	/**
	 * Getting all bunrui
	 * @return
	 */
	public List<Bunrui> getAllBunruis() {
		return new ArrayList<Bunrui>();
	}
	
	/**
	 * Get Bunrui by bunrui id
	 * @param id
	 * @return
	 */
	public Bunrui getBunruiById(int id) {
		return null;
	}

}
