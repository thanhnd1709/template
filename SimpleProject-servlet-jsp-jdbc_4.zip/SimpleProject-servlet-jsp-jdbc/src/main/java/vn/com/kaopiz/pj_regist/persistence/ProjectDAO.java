package vn.com.kaopiz.pj_regist.persistence;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.kaopiz.pj_regist.config.ConnectionFactory;
import vn.com.kaopiz.pj_regist.model.Project;

public class ProjectDAO {
	
	private Connection connection = ConnectionFactory.getConnection();
	
	public void register(Project project) throws SQLException{
		if(project != null && project.getProjectId() != 0){
			update(project);
		}else{
			insert(project);
		}
	}

	/**
	 * Insert new project
	 * @param project
	 */
	public void insert(Project project) throws SQLException {
		
	}

	/**
	 * Modify existing project
	 * @param project
	 * @throws SQLException
	 */
	public void update(Project project) throws SQLException {
		
	}
	
	/**
	 * Deleting project
	 * @param project
	 * @throws SQLException
	 */
	public void delete(Project project) throws SQLException {
		
	}
	
	/**
	 * Getting all projects
	 * @return
	 */
	public List<Project> getAllProjects() {
		return new ArrayList<Project>();
	}
	
	/**
	 * Get project by project id
	 * @param projectId
	 * @return
	 */
	public Project getProjectById(int projectId) {
		return null;
	}

}
