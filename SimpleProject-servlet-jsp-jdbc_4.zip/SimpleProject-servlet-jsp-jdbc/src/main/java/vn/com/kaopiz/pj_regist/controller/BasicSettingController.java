package vn.com.kaopiz.pj_regist.controller;

public class BasicSettingController {
	

}
