package vn.com.kaopiz.pj_regist.persistence;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.kaopiz.pj_regist.config.ConnectionFactory;
import vn.com.kaopiz.pj_regist.model.BasicSetting;

public class BasicSettingDAO {
	
private Connection connection = ConnectionFactory.getConnection();
	
	public void register(BasicSetting basicSetting) throws SQLException{
		if(basicSetting != null && basicSetting.getProjectDigit() != 0){
			update(basicSetting);
		}else{
			insert(basicSetting);
		}
	}

	/**
	 * Insert new basicSetting
	 * @param basicSetting
	 */
	private void insert(BasicSetting basicSetting) {
		
	}

	/**
	 * Modify existing basicSetting
	 * @param basicSetting
	 * @throws SQLException
	 */
	private void update(BasicSetting basicSetting) throws SQLException {
		
	}
	
	/**
	 * Deleting basicSetting
	 * @param basicSetting
	 * @throws SQLException
	 */
	public void delete(BasicSetting basicSetting) throws SQLException {
		
	}
	
	/**
	 * Getting all basic setting
	 * @return
	 */
	public List<BasicSetting> getAllBasicSettings() {
		return new ArrayList<BasicSetting>();
	}

}
