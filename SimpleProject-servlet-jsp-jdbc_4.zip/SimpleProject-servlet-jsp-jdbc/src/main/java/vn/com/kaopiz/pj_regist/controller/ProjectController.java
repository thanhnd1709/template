package vn.com.kaopiz.pj_regist.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import vn.com.kaopiz.pj_regist.model.Project;
import vn.com.kaopiz.pj_regist.persistence.ProjectDAO;

@WebServlet("/projectController.do")
public class ProjectController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String action = req.getParameter("action");

		if (action != null) {
			if (action.equals("delete")) {
				delete(req, resp);
			} else if (action.equals("list")) {
				list(req, resp);
			} else if (action.equals("alter")) {
				update(req, resp);
			} else if (action.equals("insert")) {
				insert(req, resp);
			}
		} else {
			resp.sendRedirect("projectController.do?action=list");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Gson gson = new Gson();
		String projectJsonString = getReqestBody(req);
		Project project = gson.fromJson(projectJsonString, Project.class);
		ProjectDAO projectDao = new ProjectDAO();
		try {
			projectDao.register(project);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		resp.sendRedirect("projectController.do?action=list");
	}
	
	/**
	 * Delete project
	 * @param req
	 * @param resp
	 * @throws IOException
	 * @throws ServletException
	 */
	private void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		Gson gson = new Gson();
		String projectJsonString = getReqestBody(req);
		Project project = gson.fromJson(projectJsonString, Project.class);
		ProjectDAO projectDao = new ProjectDAO();
		try {
			projectDao.delete(project);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		resp.sendRedirect("projectController.do?action=list");
	}
	
	/**
	 * List all the project
	 * @param req
	 * @param resp
	 * @throws IOException
	 * @throws ServletException
	 */
	private void list(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		ProjectDAO projectDao = new ProjectDAO();
		List<Project> projects = projectDao.getAllProjects();
		req.setAttribute("projects", projects);
		resp.sendRedirect("projectController.do?action=list");
	}
	
	/**
	 * Insert new project
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */
	private void insert(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Gson gson = new Gson();
		String projectJsonString = getReqestBody(req);
		Project project = gson.fromJson(projectJsonString, Project.class);
		ProjectDAO projectDao = new ProjectDAO();
		
		try {
			projectDao.insert(project);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		resp.sendRedirect("projectController.do?action=list");
	}
	
	/**
	 * Get request body to string
	 * @param req
	 * @return
	 * @throws IOException
	 */
	private String getReqestBody(HttpServletRequest req) throws IOException {
		BufferedReader reader = req.getReader();
		StringBuilder sb = new StringBuilder();
		String line = reader.readLine();
		while (line != null) {
			sb.append(line + "\n");
			line = reader.readLine();
		}
		reader.close();
		return sb.toString();
	}

	/**
	 * Update current project
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */
	private void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Gson gson = new Gson();
		String projectJsonString = getReqestBody(req);
		Project project = gson.fromJson(projectJsonString, Project.class);
		ProjectDAO projectDao = new ProjectDAO();

		Project tempPr = projectDao.getProjectById(project.getProjectId());
		if (tempPr != null) {
			try {
				projectDao.update(tempPr);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		resp.sendRedirect("projectController.do?action=list");
	}

	
}
