package vn.com.kaopiz.pj_regist.model;

public class Bunrui {
	
	private int id;
	private String bunrui;
	private int type;
	private String comment;
	private int sortOrder;
	/**
	 * @param id
	 * @param bunrui
	 * @param type
	 * @param comment
	 * @param sortOrder
	 */
	public Bunrui(int id, String bunrui, int type, String comment, int sortOrder) {
		super();
		this.id = id;
		this.bunrui = bunrui;
		this.type = type;
		this.comment = comment;
		this.sortOrder = sortOrder;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the bunrui
	 */
	public String getBunrui() {
		return bunrui;
	}
	/**
	 * @param bunrui the bunrui to set
	 */
	public void setBunrui(String bunrui) {
		this.bunrui = bunrui;
	}
	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}
	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	/**
	 * @return the sortOrder
	 */
	public int getSortOrder() {
		return sortOrder;
	}
	/**
	 * @param sortOrder the sortOrder to set
	 */
	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}
	
}
