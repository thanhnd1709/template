package vn.com.kaopiz.pj_regist.service;

import java.sql.SQLException;
import java.util.List;

import vn.com.kaopiz.pj_regist.model.BasicSetting;

public interface BasicSettingService {
	/**
	 * insert new basicSetting
	 * @param basicSetting
	 * @throws SQLException 
	 */
	public int insert(BasicSetting basicSetting) throws SQLException;
	
	/**
	 * update current basicSetting
	 * @param basicSetting
	 * @throws SQLException 
	 */
	public int update(BasicSetting basicSetting) throws SQLException;
	
	/**
	 * delete basicSetting
	 * @param basicSetting
	 */
	public int delete(BasicSetting basicSetting) throws SQLException;
	
	/**
	 * get all basicSetting
	 * @return
	 */
	public List<BasicSetting> getAllBasicSettings() throws SQLException;
	
	/**
	 * get basic setting by id
	 * @return
	 */
	public BasicSetting getById(int id) throws SQLException;
	


}
