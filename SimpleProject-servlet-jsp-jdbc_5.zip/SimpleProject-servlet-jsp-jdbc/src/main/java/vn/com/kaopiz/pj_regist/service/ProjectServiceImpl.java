/**
 * 
 */
package vn.com.kaopiz.pj_regist.service;

import java.sql.SQLException;
import java.util.List;

import vn.com.kaopiz.pj_regist.model.Project;
import vn.com.kaopiz.pj_regist.persistence.ProjectDAO;

public class ProjectServiceImpl  implements ProjectService{

	private ProjectDAO projectDAO;
	public ProjectServiceImpl(ProjectDAO projectDAO) {
		this.projectDAO = projectDAO;
	}
	/**
	 * @return the projectDAO
	 */
	public ProjectServiceImpl() {
	}
	/**
	 * @return the projectDAO
	 */
	public ProjectDAO getProjectDAO() {
		return projectDAO;
	}
	/**
	 * @param projectDAO the projectDAO to set
	 */
	public void setProjectDAO(ProjectDAO projectDAO) {
		this.projectDAO = projectDAO;
	}
	@Override
	public int insert(Project project) throws SQLException {
		projectDAO.insert(project);
		return project.getProjectId();
	}
	@Override
	public int update(Project project) throws SQLException {
		projectDAO.update(project);
		return project.getProjectId();
	}
	@Override
	public int delete(Project project) throws SQLException{
		projectDAO.delete(project);
		return project.getProjectId();
	}
	@Override
	public List<Project> getAllProjects() throws SQLException{
		return projectDAO.getAllProjects();
	}
	@Override
	public Project getById(int id) throws SQLException {
		return projectDAO.getById(id);
	}

}
