package vn.com.kaopiz.pj_regist.model;

public class BasicSetting {
	
	private int id;
	private int bunruiMax;
	private int projectDigit;
	private int projectMin;
	private int subDigit;
	private int subMin;
	/**
	 * @param bunruiMax
	 * @param projectDigit
	 * @param projectMin
	 * @param subDigit
	 * @param subMin
	 */
	public BasicSetting(int bunruiMax, int projectDigit, int projectMin, int subDigit, int subMin, int id) {
		super();
		this.bunruiMax = bunruiMax;
		this.projectDigit = projectDigit;
		this.projectMin = projectMin;
		this.subDigit = subDigit;
		this.subMin = subMin;
		this.id = id;
	}
	/**
	 * @return the bunruiMax
	 */
	public int getBunruiMax() {
		return bunruiMax;
	}
	/**
	 * @param bunruiMax the bunruiMax to set
	 */
	public void setBunruiMax(int bunruiMax) {
		this.bunruiMax = bunruiMax;
	}
	/**
	 * @return the projectDigit
	 */
	public int getProjectDigit() {
		return projectDigit;
	}
	/**
	 * @param projectDigit the projectDigit to set
	 */
	public void setProjectDigit(int projectDigit) {
		this.projectDigit = projectDigit;
	}
	/**
	 * @return the projectMin
	 */
	public int getProjectMin() {
		return projectMin;
	}
	/**
	 * @param projectMin the projectMin to set
	 */
	public void setProjectMin(int projectMin) {
		this.projectMin = projectMin;
	}
	/**
	 * @return the subDigit
	 */
	public int getSubDigit() {
		return subDigit;
	}
	/**
	 * @param subDigit the subDigit to set
	 */
	public void setSubDigit(int subDigit) {
		this.subDigit = subDigit;
	}
	/**
	 * @return the subMin
	 */
	public int getSubMin() {
		return subMin;
	}
	/**
	 * @param subMin the subMin to set
	 */
	public void setSubMin(int subMin) {
		this.subMin = subMin;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	
}
