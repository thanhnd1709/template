package vn.com.kaopiz.pj_regist.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import vn.com.kaopiz.pj_regist.config.Constants;
import vn.com.kaopiz.pj_regist.dto.BunruiRequestDTO;
import vn.com.kaopiz.pj_regist.dto.ResponseDTO;
import vn.com.kaopiz.pj_regist.persistence.BunruiDAO;
import vn.com.kaopiz.pj_regist.service.BunruiService;
import vn.com.kaopiz.pj_regist.service.BunruiServiceImpl;

@WebServlet("/bunruiController.do")
public class BunruiController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Getting the json content
		Gson gson = new Gson();
		String bunruiJsonString = getReqestBody(req);
		BunruiRequestDTO bunruiDTO = gson.fromJson(bunruiJsonString, BunruiRequestDTO.class);
		// Initializing service
		BunruiService bunruiService = new BunruiServiceImpl(new BunruiDAO());
		try {
			String param = "";
			if (Constants.ACTION_REGISTER.equals(bunruiDTO.getAction())) {
				param = bunruiService.insert(bunruiDTO.getBunrui()) +"";
			} else if (Constants.ACTION_EDIT.equals(bunruiDTO.getAction())){
				param = bunruiService.update(bunruiDTO.getBunrui()) +"";
			} else if (Constants.ACTION_GET.equals(bunruiDTO.getAction())){
				param = gson.toJson(bunruiService.getAllBunruis());
			} else if (Constants.ACTION_DELETE.equals(bunruiDTO.getAction())){
				param = bunruiService.delete(bunruiDTO.getBunrui()) +"";
			} else {
				throw new Exception("Action not supported");
			}
			ResponseDTO successResponse = new ResponseDTO();
			successResponse.setResult(ResponseDTO.ResponseResult.OK);
			successResponse.setParameter(param);
			sendResponse(resp, successResponse);
			
		} catch (Exception exception) {
			ResponseDTO errorResponse = new ResponseDTO();
			errorResponse.setErrorMessage(exception.getMessage());
			errorResponse.setResult(ResponseDTO.ResponseResult.NG);
			sendResponse(resp, errorResponse);
			exception.printStackTrace();
		}
		
	}

	/**
	 * @param resp
	 * @param gson
	 * @param param
	 * @throws IOException
	 */
	private void sendResponse(HttpServletResponse resp, ResponseDTO response) throws IOException {
		Gson gson = new Gson();
		String result = gson.toJson(response);
		resp.setContentType("text/html; charset=UTF-8");
		resp.setCharacterEncoding("UTF-8");
		PrintWriter out;
		out = resp.getWriter();
		out.print(result);
	}
	
	/**
	 * Get request body to string
	 * @param req
	 * @return
	 * @throws IOException
	 */
	private String getReqestBody(HttpServletRequest req) throws IOException {
		BufferedReader reader = req.getReader();
		StringBuilder sb = new StringBuilder();
		String line = reader.readLine();
		while (line != null) {
			sb.append(line + "\n");
			line = reader.readLine();
		}
		reader.close();
		return sb.toString();
	}

	
}
