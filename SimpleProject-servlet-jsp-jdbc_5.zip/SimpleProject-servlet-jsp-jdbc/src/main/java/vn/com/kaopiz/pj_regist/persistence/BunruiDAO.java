package vn.com.kaopiz.pj_regist.persistence;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.kaopiz.pj_regist.config.ConnectionFactory;
import vn.com.kaopiz.pj_regist.model.Bunrui;

public class BunruiDAO {
	
private Connection connection = ConnectionFactory.getConnection();

	/**
	 * Insert new bunrui
	 * @param bunrui
	 */
	public void insert(Bunrui bunrui) throws SQLException{
		
	}

	/**
	 * Modify existing bunrui
	 * @param bunrui
	 * @throws SQLException
	 */
	public void update(Bunrui bunrui) throws SQLException {
		
	}
	
	/**
	 * Deleting bunrui
	 * @param bunrui
	 * @throws SQLException
	 */
	public void delete(Bunrui bunrui) throws SQLException {
		
	}
	
	/**
	 * Getting all bunrui
	 * @return
	 */
	public List<Bunrui> getAllBunruis() throws SQLException{
		return new ArrayList<Bunrui>();
	}
	
	/**
	 * Get Bunrui by bunrui id
	 * @param id
	 * @return
	 */
	public Bunrui getById(int id) {
		return null;
	}

}
