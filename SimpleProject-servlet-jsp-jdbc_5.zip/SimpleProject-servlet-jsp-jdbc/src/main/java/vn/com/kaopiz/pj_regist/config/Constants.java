package vn.com.kaopiz.pj_regist.config;

public class Constants {
	
	public static final String ACTION_REGISTER = "register";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_GET = "list";
	public static final String ACTION_EDIT = "edit";
}
