package vn.com.kaopiz.pj_regist.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.kaopiz.pj_regist.config.ConnectionFactory;
import vn.com.kaopiz.pj_regist.model.Project;

public class ProjectDAO {
	
	private Connection connection = ConnectionFactory.getConnection();
	
	/**
	 * Insert new project
	 * @param project
	 */
	public void insert(Project project) throws SQLException {
		String sql = "insert into t_project ("
				+ "project_id, "
				+ "bunrui_id, "
				+ "project_no, "
				+ "sub_code, "
				+ "project_name, "
				+ "sub_name, "
				+ "project_leader, "
				+ "project_leader_name, "
				+ "webts_pj_id ) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, project.getProjectId());
			statement.setInt(2, project.getBunnruiId());
			statement.setInt(3, project.getProjectNo());
			statement.setInt(4, project.getSubCode());
			statement.setString(5, project.getProjectName());
			statement.setString(6, project.getSubName());
			statement.setInt(7, project.getProjectLeader());
			statement.setString(8, project.getProjectLeaderName());
			statement.setInt(9, project.getWebTSPjId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Modify existing project
	 * @param project
	 * @throws SQLException
	 */
	public void update(Project project) throws SQLException {
		String sql = "update t_project set "
				+ "bunrui_id = ?,  "
				+ "project_no = ?, "
				+ "sub_code = ?, "
				+ "project_name = ? "
				+ "sub_name = ? "
				+ "project_leader = ? "
				+ "project_leader_name = ? "
				+ "webts_pj_id = ? "
				+ "where project_id = ?";
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, project.getBunnruiId());
			statement.setInt(2, project.getProjectNo());
			statement.setInt(3, project.getSubCode());
			statement.setString(4, project.getProjectName());
			statement.setString(5, project.getSubName());
			statement.setInt(6, project.getProjectLeader());
			statement.setString(7, project.getProjectLeaderName());
			statement.setInt(8, project.getWebTSPjId());
			statement.setInt(9, project.getProjectId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Deleting project
	 * @param project
	 * @throws SQLException
	 */
	public void delete(Project project) throws SQLException {
		String sql = "delete from t_project where project_id = ?";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, project.getProjectId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Getting all projects
	 * @return
	 */
	public List<Project> getAllProjects() {
		List<Project> projectList = new ArrayList<Project>();
        ResultSet rs;
        PreparedStatement statement = null;
        try {
            String sql = "select * from t_project order by project_id";
            statement = connection.prepareStatement(sql);
            rs = statement.executeQuery();
            while (rs.next()) {
            	Project tempProject = new Project();
            	tempProject.setProjectId(Integer.parseInt(rs.getString("project_id")));
            	tempProject.setBunnruiId(Integer.parseInt(rs.getString("bunrui_id")));
            	tempProject.setProjectNo(Integer.parseInt(rs.getString("project_no")));
            	tempProject.setSubCode(Integer.parseInt(rs.getString("sub_code")));
            	tempProject.setProjectName(rs.getString("project_name"));
            	tempProject.setSubName(rs.getString("sub_name"));
            	tempProject.setProjectLeaderName(rs.getString("project_leader"));
            	tempProject.setProjectLeader(Integer.parseInt(rs.getString("project_leader_name")));
            	tempProject.setWebTSPjId(Integer.parseInt(rs.getString("webts_pj_id")));
                projectList.add(tempProject);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return projectList;
	}

	public Project getById(int id) {
		ResultSet rs;
        PreparedStatement statement = null;
        Project tempProject = null;
        try {
            String sql = "select * from users where id = ?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            rs = statement.executeQuery();
            if(rs.next()) {
            	tempProject = new Project();
            	tempProject.setProjectId(Integer.parseInt(rs.getString("project_id")));
            	tempProject.setBunnruiId(Integer.parseInt(rs.getString("bunrui_id")));
            	tempProject.setProjectNo(Integer.parseInt(rs.getString("project_no")));
            	tempProject.setSubCode(Integer.parseInt(rs.getString("sub_code")));
            	tempProject.setProjectName(rs.getString("project_name"));
            	tempProject.setSubName(rs.getString("sub_name"));
            	tempProject.setProjectLeaderName(rs.getString("project_leader"));
            	tempProject.setProjectLeader(Integer.parseInt(rs.getString("project_leader_name")));
            	tempProject.setWebTSPjId(Integer.parseInt(rs.getString("webts_pj_id")));

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return tempProject;
	}

}
