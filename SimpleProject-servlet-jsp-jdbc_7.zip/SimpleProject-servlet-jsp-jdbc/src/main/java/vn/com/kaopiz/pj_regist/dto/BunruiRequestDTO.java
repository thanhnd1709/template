package vn.com.kaopiz.pj_regist.dto;

import vn.com.kaopiz.pj_regist.model.Bunrui;

public class BunruiRequestDTO {

	public String action;
	public Bunrui bunrui;
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the bunrui
	 */
	public Bunrui getBunrui() {
		return bunrui;
	}
	/**
	 * @param bunrui the bunrui to set
	 */
	public void setBunrui(Bunrui bunrui) {
		this.bunrui = bunrui;
	}
	/**
	 * @param action
	 * @param bunrui
	 */
	public BunruiRequestDTO(String action, Bunrui bunrui) {
		super();
		this.action = action;
		this.bunrui = bunrui;
	}
}
