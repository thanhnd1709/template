package vn.com.kaopiz.pj_regist.model;

public class Project {
	
	private int projectId;
	private int bunnruiId;
	private int projectNo;
	private int subCode;
	private String projectName;
	private String subName;
	private int projectLeader;
	private String projectLeaderName;
	private int WebTSPjId;
	
	/**
	 * @param projectId
	 * @param bunnruiId
	 * @param projectNo
	 * @param subCode
	 * @param projectName
	 * @param subName
	 * @param projectLeader
	 * @param projectLeaderName
	 * @param webTSPjId
	 */
	public Project(int projectId, int bunnruiId, int projectNo, int subCode, String projectName, String subName,
			int projectLeader, String projectLeaderName, int webTSPjId) {
		super();
		this.projectId = projectId;
		this.bunnruiId = bunnruiId;
		this.projectNo = projectNo;
		this.subCode = subCode;
		this.projectName = projectName;
		this.subName = subName;
		this.projectLeader = projectLeader;
		this.projectLeaderName = projectLeaderName;
		WebTSPjId = webTSPjId;
	}

	public Project() {
	}

	/**
	 * @return the projectId
	 */
	public int getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the bunnruiId
	 */
	public int getBunnruiId() {
		return bunnruiId;
	}

	/**
	 * @param bunnruiId the bunnruiId to set
	 */
	public void setBunnruiId(int bunnruiId) {
		this.bunnruiId = bunnruiId;
	}

	/**
	 * @return the projectNo
	 */
	public int getProjectNo() {
		return projectNo;
	}

	/**
	 * @param projectNo the projectNo to set
	 */
	public void setProjectNo(int projectNo) {
		this.projectNo = projectNo;
	}

	/**
	 * @return the subCode
	 */
	public int getSubCode() {
		return subCode;
	}

	/**
	 * @param subCode the subCode to set
	 */
	public void setSubCode(int subCode) {
		this.subCode = subCode;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the subName
	 */
	public String getSubName() {
		return subName;
	}

	/**
	 * @param subName the subName to set
	 */
	public void setSubName(String subName) {
		this.subName = subName;
	}

	/**
	 * @return the projectLeader
	 */
	public int getProjectLeader() {
		return projectLeader;
	}

	/**
	 * @param projectLeader the projectLeader to set
	 */
	public void setProjectLeader(int projectLeader) {
		this.projectLeader = projectLeader;
	}

	/**
	 * @return the projectLeaderName
	 */
	public String getProjectLeaderName() {
		return projectLeaderName;
	}

	/**
	 * @param projectLeaderName the projectLeaderName to set
	 */
	public void setProjectLeaderName(String projectLeaderName) {
		this.projectLeaderName = projectLeaderName;
	}

	/**
	 * @return the webTSPjId
	 */
	public int getWebTSPjId() {
		return WebTSPjId;
	}

	/**
	 * @param webTSPjId the webTSPjId to set
	 */
	public void setWebTSPjId(int webTSPjId) {
		WebTSPjId = webTSPjId;
	}
	
	
	

}
