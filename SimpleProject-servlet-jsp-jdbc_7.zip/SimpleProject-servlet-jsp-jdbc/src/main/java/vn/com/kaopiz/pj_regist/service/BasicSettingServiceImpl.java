/**
 * 
 */
package vn.com.kaopiz.pj_regist.service;

import java.sql.SQLException;
import java.util.List;

import vn.com.kaopiz.pj_regist.model.BasicSetting;
import vn.com.kaopiz.pj_regist.persistence.BasicSettingDAO;

public class BasicSettingServiceImpl  implements BasicSettingService{

	private BasicSettingDAO basicSettingDAO;
	public BasicSettingServiceImpl(BasicSettingDAO basicSettingDAO) {
		this.basicSettingDAO = basicSettingDAO;
	}
	/**
	 * @return the basicSettingDAO
	 */
	public BasicSettingServiceImpl() {
	}
	/**
	 * @return the basicSettingDAO
	 */
	public BasicSettingDAO getBasicSettingDAO() {
		return basicSettingDAO;
	}
	/**
	 * @param basicSettingDAO the basicSettingDAO to set
	 */
	public void setBasicSettingDAO(BasicSettingDAO basicSettingDAO) {
		this.basicSettingDAO = basicSettingDAO;
	}
	@Override
	public int insert(BasicSetting basicSetting) throws SQLException {
		basicSettingDAO.insert(basicSetting);
		return basicSetting.getId();
	}
	@Override
	public int update(BasicSetting basicSetting) throws SQLException {
		basicSettingDAO.update(basicSetting);
		return basicSetting.getId();
	}
	@Override
	public int delete(BasicSetting basicSetting) throws SQLException{
		basicSettingDAO.delete(basicSetting);
		return basicSetting.getId();
	}
	@Override
	public List<BasicSetting> getAllBasicSettings() throws SQLException{
		return basicSettingDAO.getAllBasicSettings();
	}
	@Override
	public BasicSetting getById(int id) throws SQLException {
		return basicSettingDAO.getById(id);
	}

}
