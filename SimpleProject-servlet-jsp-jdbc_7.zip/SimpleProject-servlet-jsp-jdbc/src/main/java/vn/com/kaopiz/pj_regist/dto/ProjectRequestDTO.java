package vn.com.kaopiz.pj_regist.dto;

import com.google.gson.Gson;

import vn.com.kaopiz.pj_regist.config.Constants;
import vn.com.kaopiz.pj_regist.model.Project;

public class ProjectRequestDTO {

	public String action;
	public Project project;
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}
	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}
	/**
	 * @param action
	 * @param project
	 */
	public ProjectRequestDTO(String action, Project project) {
		super();
		this.action = action;
		this.project = project;
	}
	public static void main(String[] args) {
		Project project = new Project(1, 2, 002, 22, "OM", "Sub", 003, "ThanhND", 01);
		ProjectRequestDTO projectDTO = new ProjectRequestDTO(Constants.ACTION_REGISTER, project);
		Gson gon = new Gson();
		System.out.println(gon.toJson(projectDTO));
	}
}
