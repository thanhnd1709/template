var tescoUtil = {};

if ('undefined' == typeof module) {
  window.tescoUtil = tescoUtil;
} else {
  module.exports = tescoUtil;
}

/**
 * exception utility function
 */
tescoUtil.exception = {
	/**
	 * create exception object to use in other utility functions 
	 * @param {string} errCode exception error code
	 * @param {object} data additional data about the error
	 * @return {object} exception object
	 */
	createException: function(errCode, data) {
		var exception = {
			errCode: errCode
		};
		if (data !== null && data !== undefined) {
			exception.data = data;
		}
		return exception;
	}
}


/**
 * string utility function
 */
tescoUtil.string = {
	/**
	 * trim character in the right side of string
	 * @param {string} stringValue input string
	 * @param {char} trimmedChar the character need to be trimmed
	 * @param {number} characterCount the number of character need to be removed, 
	 *        if not input removed the specific character from the end of string until meet different character
	 * @return {string} trimmed string
	 */
	rightTrim : function(stringValue, trimmedChar , characterCount) {
		var stringLength = stringValue.length;
		var str = stringValue;
		
		var maxRemove = 0;
		if (characterCount === undefined || characterCount === null) {
			maxRemove = stringLength;
		} else {
			if (stringLength >= characterCount) {
				maxRemove = characterCount;
			} else {
				maxRemove = stringLength;
			}
		}
		
		for (var i = 0; i < maxRemove; i++) {
			if (trimmedChar != stringValue.charAt(stringLength - 1 - i)) {
				break;
			}
		}
		
		str = str.substring(0, stringLength - i);
		
		return str;
	},
	/**
	 * added spaces to end of string to create a string with specific length
	 * @param {string} inputText input string
	 * @param {number} length length of the out put string after being added space
	 * @return {string} padded string
	 */
	rPad: function(inputText, length) {
		var padlength = length - inputText.length;
		var out = inputText;
		for (var i =0; i < padlength; i ++) {
			out = out + ' ';
		}
		return out;
	},
	/**
	 * return empty string if input string is null or undefined
	 * @param {string} input input string
	 * @return {string} return empty string if input is null or undefined, otherwise return original input string
	 */
	getEmptyifUndefined: function(input) {
		if (input === null || input === undefined) {
			return '';
		}
		return input;
	}
};

/**
 * utility date function
 */
tescoUtil.date = {
	/**
	 * error code
	 */
	ERR_CODE: {
		INPUT_EMPTY: 0,
		WRONG_FORMAT: 1,
		INVALID_DATE: 2
	},
	
	/**
	 * check if input expire date is in YYYYMMDD format
	 * @param {string} expireDateString input string
	 * @throws {object} object store error code 
	 */
	checkDateFormat_YYYYMMDD: function(dateString) {
		if (dateString == "") {
			throw tescoUtil.exception.createException(this.ERR_CODE.INPUT_EMPTY);
		}
	    if (!dateString.match(/^[0-9]{8}$/)) {
	        throw tescoUtil.exception.createException(this.ERR_CODE.WRONG_FORMAT);
	    }
	    else{
	        var year  = dateString.substr(0, 4);
	        var month = dateString.substr(4, 2);
	        var day   = dateString.substr(6, 2);
	        var date = new Date(year, month - 1, day);
	        var year_new  = date.getFullYear();
	        var month_new = date.getMonth() + 1;
	        var day_new   = date.getDate();

	        if (month_new < 10) {
	            month_new = "0" + month_new;
	        }
	        if (day_new < 10) {
	            day_new = "0" + day_new;
	        }
	        if (year != year_new || month != month_new || day != day_new) {
	        	throw tescoUtil.exception.createException(this.ERR_CODE.INVALID_DATE);
	        }
	    }
	},
	/**
	 * parse input expire date in YYYYMMDD format
	 * @param {string} expireDateString input string
	 * @return {Date} date object
	 * @throws {string} error message when input in wrong format
	 */
	parseYYYYMMDDDate: function(dateString) {
		this.checkDateFormat_YYYYMMDD(dateString);
	
		var year = new Number(dateString.substring(0, 4));
		var month = new Number(dateString.substring(4, 6))-1; 
		var day = new Number(dateString.substring(6, 8));
		var date = new Date(year, month, day);
		
		if (isNaN(date)) {
			throw tescoUtil.exception.createException(this.ERR_CODE.WRONG_FORMAT);
		}
		return date;
	}
}

/**
 * generic ajax function
 */
tescoUtil.ajax = {
    /**
     * send ajax request to server. In case server send back a success response, success callback fucntion will be called, otherwise error callback function will be called.
     * @param {string} url request url 
     * @param {object} requestData data will be send in request body (json format) 
     * @param {function} successCallbackfunction call back function in case request receive success response
     * @param {function} errCallbackfunction call back function in case request receive error response
     */
	sendRequest : function(url, requestData, successCallbackfunction, errCallbackfunction) {
		var request = new XMLHttpRequest();
	
		var ajaxUtil = this;
		
		request.onload = function() {
		    if (this.readyState == 4 && this.status == 200) {
		    	if(this.responseText){
		    		console.log('response: ' + this.responseText);
		    		var responseObj = null;
		    		
		    		try {
		    			responseObj = ajaxUtil.ajaxResponseHandler(this.responseText)
		    		} catch (e) {
		    			responseObj = ajaxUtil.oldHtmlResponseHandler(this.responseText)
		    		}
		    		
		    		if (responseObj != null) {
		    			if (responseObj.result === 'OK') {
			    			if (successCallbackfunction !== null && successCallbackfunction !== undefined) {
			    				successCallbackfunction(responseObj, requestData);
			    			}
			    		} else {
			    			if (errCallbackfunction !== null && errCallbackfunction !== undefined) {
			    				errCallbackfunction(responseObj, requestData);
			    			}
			    		}
		    		} else {
		    			ajaxUtil.responseUnknownException(errCallbackfunction, requestData);
		    		}
		    	} else {
		    		ajaxUtil.responseUnknownException(errCallbackfunction, requestData);
		    	}
		    } else {
		    	ajaxUtil.responseUnknownException(errCallbackfunction, requestData);
	    	}
		};
		
		request.open("POST", url, true);
		request.timeout = 300000;
		request.setRequestHeader("Content-type", "application/json; charset=UTF-8");
		
		console.log('request: ' + url);
		console.log('request data: ' + JSON.stringify(requestData));
		
		request.send(JSON.stringify(requestData));
	},
    /**
     * create response object from Ajax request's response text
     * @param {string} responseText response text of Ajax request
     * @return {object} response object
     */
	ajaxResponseHandler: function (responseText) {
		var responseObj = JSON.parse(responseText);
		
		return responseObj;
	},
    /**
     * create response object from old style response: Html page for error code
     * @param {string} responseText response text of Ajax request
     * @return {object} response object
     */
	oldHtmlResponseHandler: function (responseText) {
		var responseObj = null;
		var errMsg = null;
		
		var tempElement = document.createElement('div');
		tempElement.innerHTML = responseText;

		try {
			errMsg = tempElement.getElementsByTagName('td')[0].textContent.trim();
		} catch(e) {
			errMsg = null;
		}
		
		if (errMsg !== null && errMsg !== undefined) {
			responseObj = {};
			responseObj.result = 'NG';
			responseObj.errorMessage = errMsg;
		}
		
		return responseObj;
	},
    /**
     * create response "unknown exception" and notify caller screen
     * @param {function} errCallbackfunction function to notify caller screen 
     * @param {object} requestData input data from caller screen
     */
	responseUnknownException: function(errCallbackfunction, requestData) {
		if (errCallbackfunction !== null && errCallbackfunction !== undefined) {
			var responseObj = {};
    		responseObj.result = 'NG';
    		responseObj.errorCode = 'E00001'; // error code for unknown exception
    		errCallbackfunction(responseObj, requestData);
		}
	}
};