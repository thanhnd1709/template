package vn.com.pj_regist.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import vn.com.pj_regist.dto.ResponseDTO;

public class BaseController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * @param resp
	 * @param gson
	 * @param param
	 * @throws IOException
	 */
	protected void sendResponse(HttpServletResponse resp, ResponseDTO response) throws IOException {
		Gson gson = new Gson();
		String result = gson.toJson(response);
		resp.setContentType("text/html; charset=UTF-8");
		resp.setCharacterEncoding("UTF-8");
		PrintWriter out;
		out = resp.getWriter();
		out.print(result);
	}
	
	/**
	 * Get request body to string
	 * @param req
	 * @return
	 * @throws IOException
	 */
	protected String getReqestBody(HttpServletRequest req) throws IOException {
		BufferedReader reader = req.getReader();
		StringBuilder sb = new StringBuilder();
		String line = reader.readLine();
		while (line != null) {
			sb.append(line + "\n");
			line = reader.readLine();
		}
		reader.close();
		return sb.toString();
	}
	
}
