package vn.com.pj_regist.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.pj_regist.dto.BunruiRequestDTO;
import vn.com.pj_regist.model.Bunrui;

public interface BunruiService {
	/**
	 * insert new bunrui
	 * @param bunrui
	 * @throws SQLException 
	 */
	//public int insert(Bunrui bunrui) throws SQLException;
	
	/**
	 * update current bunrui
	 * @param bunrui
	 * @throws SQLException 
	 */
	//public int update(Bunrui bunrui) throws SQLException;
	
	/**
	 * delete bunrui
	 * @param bunrui
	 */
	//public int delete(Bunrui bunrui) throws SQLException;
	
	/**
	 * get all bunrui
	 * @return
	 */
	public List<Bunrui> getAllBunruis() throws SQLException;
	
	/**
	 * get basic setting by id
	 * @return
	 */
	public Bunrui getById(int id) throws SQLException;
	
	/**
	 * insert new bunrui
	 * @param bunrui
	 * @throws SQLException 
	 */
	public int save(BunruiRequestDTO bunruiDTO) throws SQLException;
	

}
