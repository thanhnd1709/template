package vn.com.pj_regist.dto;

import vn.com.pj_regist.model.BasicSetting;

public class BasicSettingRequestDTO {

	public String action;
	public BasicSetting basicSetting;
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the basicSetting
	 */
	public BasicSetting getBasicSetting() {
		return basicSetting;
	}
	/**
	 * @param basicSetting the basicSetting to set
	 */
	public void setBasicSetting(BasicSetting basicSetting) {
		this.basicSetting = basicSetting;
	}
	/**
	 * @param action
	 * @param basicSetting
	 */
	public BasicSettingRequestDTO(String action, BasicSetting basicSetting) {
		super();
		this.action = action;
		this.basicSetting = basicSetting;
	}
}
