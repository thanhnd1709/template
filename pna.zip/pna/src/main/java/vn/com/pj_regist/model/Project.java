package vn.com.pj_regist.model;

public class Project {
	
	private int projectId;
	private int bunruiId;
	private int projectNo;
	private int subCode;
	private String projectName;
	private String subName;
	private int projectLeader;
	private String projectLeaderName;
	private int webTSPjId;
	private String projectInfo;
	private String[] projectMemberIds;
	private String bunrui;
	/**
	 * @param projectId
	 * @param bunnruiId
	 * @param projectNo
	 * @param subCode
	 * @param projectName
	 * @param subName
	 * @param projectLeader
	 * @param projectLeaderName
	 * @param webTSPjId
	 */
	public Project(int projectId, int bunnruiId, int projectNo, int subCode, String projectName, String subName,
			int projectLeader, String projectLeaderName, int webTSPjId) {
		super();
		this.projectId = projectId;
		this.bunruiId = bunnruiId;
		this.projectNo = projectNo;
		this.subCode = subCode;
		this.projectName = projectName;
		this.subName = subName;
		this.projectLeader = projectLeader;
		this.projectLeaderName = projectLeaderName;
		this.webTSPjId = webTSPjId;
	}

	public Project() {
	}

	/**
	 * @return the projectId
	 */
	public int getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the bunnruiId
	 */
	public int getBunruiId() {
		return bunruiId;
	}

	/**
	 * @param bunnruiId the bunnruiId to set
	 */
	public void setBunruiId(int bunnruiId) {
		this.bunruiId = bunnruiId;
	}

	/**
	 * @return the projectNo
	 */
	public int getProjectNo() {
		return projectNo;
	}

	/**
	 * @param projectNo the projectNo to set
	 */
	public void setProjectNo(int projectNo) {
		this.projectNo = projectNo;
	}

	/**
	 * @return the subCode
	 */
	public int getSubCode() {
		return subCode;
	}

	/**
	 * @param subCode the subCode to set
	 */
	public void setSubCode(int subCode) {
		this.subCode = subCode;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the subName
	 */
	public String getSubName() {
		return subName;
	}

	/**
	 * @param subName the subName to set
	 */
	public void setSubName(String subName) {
		this.subName = subName;
	}

	/**
	 * @return the projectLeader
	 */
	public int getProjectLeader() {
		return projectLeader;
	}

	/**
	 * @param projectLeader the projectLeader to set
	 */
	public void setProjectLeader(int projectLeader) {
		this.projectLeader = projectLeader;
	}

	/**
	 * @return the projectLeaderName
	 */
	public String getProjectLeaderName() {
		return projectLeaderName;
	}

	/**
	 * @param projectLeaderName the projectLeaderName to set
	 */
	public void setProjectLeaderName(String projectLeaderName) {
		this.projectLeaderName = projectLeaderName;
	}

	/**
	 * @return the webTSPjId
	 */
	public int getWebTSPjId() {
		return webTSPjId;
	}

	/**
	 * @param webTSPjId the webTSPjId to set
	 */
	public void setWebTSPjId(int webTSPjId) {
		this.webTSPjId = webTSPjId;
	}

	/**
	 * @return the projectInfo
	 */
	public String getProjectInfo() {
		return projectInfo;
	}

	/**
	 * @param projectInfo the projectInfo to set
	 */
	public void setProjectInfo(String projectInfo) {
		this.projectInfo = projectInfo;
	}

	/**
	 * @return the projectMemberIds
	 */
	public String[] getProjectMemberIds() {
		return projectMemberIds;
	}

	/**
	 * @param projectMemberIds the projectMemberIds to set
	 */
	public void setProjectMemberIds(String[] projectMemberIds) {
		this.projectMemberIds = projectMemberIds;
	}

	/**
	 * @return the bunrui
	 */
	public String getBunrui() {
		return bunrui;
	}

	/**
	 * @param bunrui the bunrui to set
	 */
	public void setBunrui(String bunrui) {
		this.bunrui = bunrui;
	}
	
}
