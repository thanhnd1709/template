package vn.com.pj_regist.api;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import vn.com.pj_regist.config.ResourceUtility;
import vn.com.pj_regist.config.Utils;

public class WebTSClient {

	private static final String BASE_URL = ResourceUtility.getConfig("webts.base.url");
	private static final String QUESTION_MARK = "?";

	/**
	 * Handle all the get request
	 * 
	 * @param params
	 * @return
	 * @throws URISyntaxException
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static JSONObject doGet(Map<?, ?> params) throws URISyntaxException, ClientProtocolException, IOException {

		String requestURL = (new StringBuilder()).append(BASE_URL).append(QUESTION_MARK).append(Utils.urlEncodeUTF8(params))
				.toString();
		URIBuilder builder = new URIBuilder(requestURL);
		HttpGet httpGet = new HttpGet(builder.build());
		HttpClient client = HttpClientBuilder.create().build();
		HttpResponse response = client.execute(httpGet);
		return new JSONObject(EntityUtils.toString(response.getEntity()));
	}
	
}
