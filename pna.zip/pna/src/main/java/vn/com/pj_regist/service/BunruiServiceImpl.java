package vn.com.pj_regist.service;

import java.sql.SQLException;
import java.util.List;

import vn.com.pj_regist.dto.BunruiRequestDTO;
import vn.com.pj_regist.model.Bunrui;
import vn.com.pj_regist.persistence.BunruiDAO;

public class BunruiServiceImpl  implements BunruiService{

	private BunruiDAO bunruiDAO;
	public BunruiServiceImpl(BunruiDAO bunruiDAO) {
		this.bunruiDAO = bunruiDAO;
	}
	/**
	 * @return the bunruiDAO
	 */
	public BunruiServiceImpl() {
	}
	/**
	 * @return the bunruiDAO
	 */
	public BunruiDAO getBunruiDAO() {
		return bunruiDAO;
	}
	/**
	 * @param bunruiDAO the bunruiDAO to set
	 */
	public void setBunruiDAO(BunruiDAO bunruiDAO) {
		this.bunruiDAO = bunruiDAO;
	}
	/*
	 * (non-Javadoc)
	 * @see vn.com.pj_regist.service.BunruiService#getAllBunruis()
	 */
	@Override
	public List<Bunrui> getAllBunruis() throws SQLException{
		return bunruiDAO.getAllBunruis();
	}
	/*
	 * (non-Javadoc)
	 * @see vn.com.pj_regist.service.BunruiService#getById(int)
	 */
	@Override
	public Bunrui getById(int id) throws SQLException {
		return bunruiDAO.getById(id);
	}
	/*
	 * (non-Javadoc)
	 * @see vn.com.pj_regist.service.BunruiService#save(vn.com.pj_regist.dto.BunruiRequestDTO)
	 */
	@Override
	public int save(BunruiRequestDTO bunruiDTO) throws SQLException{
		bunruiDAO.save(bunruiDTO);
		return 0;
	}

}
