/**
 * 
 */
package vn.com.pj_regist.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.json.JSONObject;

import vn.com.pj_regist.api.WebTSClient;
import vn.com.pj_regist.config.Constants;
import vn.com.pj_regist.dto.ProjectRequestDTO;
import vn.com.pj_regist.model.Project;
import vn.com.pj_regist.persistence.ProjectDAO;

public class ProjectServiceImpl  implements ProjectService{

	private ProjectDAO projectDAO;
	public ProjectServiceImpl(ProjectDAO projectDAO) {
		this.projectDAO = projectDAO;
	}
	/**
	 * @return the projectDAO
	 */
	public ProjectServiceImpl() {
	}
	/**
	 * @return the projectDAO
	 */
	public ProjectDAO getProjectDAO() {
		return projectDAO;
	}
	/**
	 * @param projectDAO the projectDAO to set
	 */
	public void setProjectDAO(ProjectDAO projectDAO) {
		this.projectDAO = projectDAO;
	}
	/**
	 * Insert project to webts and local database
	 */
	@Override
	public int insert(ProjectRequestDTO projectDTO) throws Exception {
		Project project = projectDTO.getProject();
		int projectId = projectDAO.insert(project);
		if (!projectDTO.isWebtsCheck()) {
			return projectId;
		} else {
			Map<String,String> map = new HashMap<String,String>();
			map.put("cmd", Constants.ADD_PROJECT);
			map.put("param1", project.getProjectInfo());
			map.put("param2",  project.getProjectName());
			map.put("param3", projectId + "");
			String[] mb_emp_no = project.getProjectMemberIds();
			String param4String = "[";
			if (mb_emp_no.length == 0) {
				param4String = "[]";
			} else {
				for (int i = 0; i < mb_emp_no.length; i ++) {
					if ( i == mb_emp_no.length - 1) {
						param4String = param4String + mb_emp_no[i] + "]";
					} else {
						param4String = param4String + mb_emp_no[i] + ",";
					}
				}
			}
			map.put("param4", param4String);
			JSONObject result = null;
			String responseCode = "";
			try {
				result = WebTSClient.doGet(map);
				responseCode = result.get("status").toString();
			} catch (Exception e) {
				projectDAO.delete(project);
				e.printStackTrace();
				responseCode = Constants.NETWORK_CONNECTION_ERROR;
			} 
			if (Constants.NETWORK_CONNECTION_ERROR.equals(responseCode)) {
				projectDAO.delete(project);
				throw new Exception(Constants.NETWORK_CONNECTION_ERROR);
			} else if (Constants.DUPLICATE_PROJECT_ERROR.equals(responseCode)) {
				projectDAO.delete(project);
				throw new Exception(Constants.DUPLICATE_PROJECT_ERROR);
			} else if (Constants.SUCCESSFUL_STATUS.equals(responseCode)){
				project.setWebTSPjId(Integer.parseInt(result.get("project_id").toString()));
				projectDAO.update(project);
			}
			return project.getProjectId();
		}
	}
	@Override
	public int update(ProjectRequestDTO projectDTO) throws Exception {
		Project project = projectDTO.getProject();
		if (!projectDTO.isWebtsCheck()) {
			projectDAO.update(project);
			return project.getProjectId();
		} else {
			Map<String,String> map = new HashMap<String,String>();
			map.put("cmd", Constants.EDIT_PROJECT);
			map.put("param1", project.getProjectInfo());
			map.put("param2",  project.getProjectName());
			map.put("param3", project.getProjectId() + "");
			String[] mb_emp_no = project.getProjectMemberIds();
			String param4String = "[";
			if (mb_emp_no.length == 0) {
				param4String = "[]";
			} else {
				for (int i = 0; i < mb_emp_no.length; i ++) {
					if ( i == mb_emp_no.length - 1) {
						param4String = param4String + mb_emp_no[i] + "]";
					} else {
						param4String = param4String + mb_emp_no[i] + ",";
					}
				}
			}
			map.put("param4", param4String);
			JSONObject result = null;
			String responseCode = "";
			try {
				result = WebTSClient.doGet(map);
				responseCode = result.get("status").toString();
			} catch (Exception e) {
				e.printStackTrace();
				responseCode = Constants.NETWORK_CONNECTION_ERROR;
			} 
			if (Constants.NETWORK_CONNECTION_ERROR.equals(responseCode)) {
				throw new Exception(Constants.NETWORK_CONNECTION_ERROR);
			} else if (Constants.DUPLICATE_PROJECT_ERROR.equals(responseCode)) {
				throw new Exception(Constants.DUPLICATE_PROJECT_ERROR);
			} else if (Constants.UPDATE_NOT_FOUND_ERROR.equals(responseCode)) {
				throw new Exception(Constants.UPDATE_NOT_FOUND_ERROR);
			} else if (Constants.SUCCESSFUL_STATUS.equals(responseCode)){
				projectDAO.update(project);
			}
			return project.getProjectId();
		}
	}
	@Override
	public int delete(ProjectRequestDTO projectDTO) throws Exception{
		Project project = projectDTO.getProject();
		if (!projectDTO.isWebtsCheck()) {
			projectDAO.delete(project);
			return project.getProjectId();
		} else {
			Map<String,String> map = new HashMap<String,String>();
			map.put("cmd", Constants.DELETE_PROJECT);
			map.put("param1", project.getProjectId()+"");
			JSONObject result = null;
			String responseCode = "";
			try {
				result = WebTSClient.doGet(map);
				responseCode = result.get("status").toString();
			} catch (Exception e) {
				e.printStackTrace();
				responseCode = Constants.NETWORK_CONNECTION_ERROR;
			}
			if (Constants.NETWORK_CONNECTION_ERROR.equals(responseCode)) {
				throw new Exception(Constants.NETWORK_CONNECTION_ERROR);
			} else if (Constants.DELETE_NOT_FOUND_ERROR.equals(responseCode)) {
				throw new Exception(Constants.DELETE_NOT_FOUND_ERROR);
			} else if (Constants.NO_DELETION_TARGET_ERROR.equals(responseCode)) {
				throw new Exception(Constants.NO_DELETION_TARGET_ERROR);
			} else if (Constants.SUCCESSFUL_STATUS.equals(responseCode)){
				projectDAO.delete(project);
			}
			return project.getProjectId();
		}
	}
	@Override
	public List<Project> getAllProjects() throws SQLException{
		return projectDAO.getAllProjects();
	}
	@Override
	public Project getById(int id) throws SQLException {
		return projectDAO.getById(id);
	}
	@Override
	public List<Project> searchProject(Project project) throws SQLException {
		return projectDAO.searchProject(project);
	}

}
