package vn.com.pj_regist.dto;

import vn.com.pj_regist.model.Project;

public class ProjectRequestDTO {

	public String action;
	public Project project;
	public boolean webtsCheck;
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}
	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}
	/**
	 * @return the webtsCheck
	 */
	public boolean isWebtsCheck() {
		return webtsCheck;
	}
	/**
	 * @param webtsCheck the webtsCheck to set
	 */
	public void setWebtsCheck(boolean webtsCheck) {
		this.webtsCheck = webtsCheck;
	}
	
}
