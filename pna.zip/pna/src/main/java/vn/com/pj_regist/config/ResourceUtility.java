package vn.com.pj_regist.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ResourceUtility {
	public static ClassLoader classLoader;
	public static Properties configurations;
	
	/**
	 * Getting message by message nane
	 * @param name
	 * @return
	 */
	public static String getConfig(String name) {
		if (configurations == null) {
			configurations = new Properties();
			try {
				classLoader = Thread.currentThread().getContextClassLoader();
				InputStream input = classLoader.getResourceAsStream("config.properties");
				configurations.load(input);
				return configurations.getProperty(name);
			}  catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return configurations.getProperty(name);
		}	
	}

}
