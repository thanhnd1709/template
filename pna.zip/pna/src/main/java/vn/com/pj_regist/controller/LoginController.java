
package vn.com.pj_regist.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import vn.com.pj_regist.config.Constants;
import vn.com.pj_regist.service.LoginService;
import vn.com.pj_regist.service.LoginServiceImpl;

@WebServlet("/login")
public class LoginController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// get request parameters for userID and password
		LoginService loginService = new LoginServiceImpl();
		String result = loginService.doLogin(request.getParameter("user"), request.getParameter("pass"));
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/jsp/login.jsp");
		switch(result) {
			case Constants.LOGIN_SUCCESS:
				HttpSession session = request.getSession();
				session.setAttribute("user", request.getParameter("user"));
				session.setMaxInactiveInterval(Constants.MAX_INTERVAL);
				Cookie userName = new Cookie("user", request.getParameter("user"));
				userName.setMaxAge(Constants.MAX_INTERVAL);
				response.addCookie(userName);
				response.sendRedirect("project");
				break;
			case Constants.LOGIN_AUTHENTICATE_FAILURE:
				request.setAttribute("firstMessage", "認証に失敗しました。");
				request.setAttribute("secondMessage", "ユーザー名、パスワードを確認してください");
				rd.forward(request, response);
				break;
			case Constants.LOGIN_NO_USER_RIGHT:
				request.setAttribute("firstMessage", "プロジェクト番号採番の利用権限がありません。");
				rd.forward(request, response);
				break;
			case Constants.API_CALL_ERROR:
				request.setAttribute("firstMessage", "通信に失敗しました。");
				rd.forward(request, response);
				break;
		}
	}
	/**
	 * Handle get method to login page
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/jsp/login.jsp");
		dispatcher.forward(request, response);

	}
	
	

}
