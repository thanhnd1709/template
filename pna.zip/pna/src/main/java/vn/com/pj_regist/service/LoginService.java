package vn.com.pj_regist.service;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

public interface LoginService {
	
//	/**
//	 * Call the WebTS API to login
//	 * @return
//	 * @throws IOException 
//	 * @throws ClientProtocolException 
//	 */
//	public boolean doLogin(String username, String password) throws ClientProtocolException, IOException;
	
	/**
	 * Call the WebTS API to login
	 * @return
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	public String doLogin(String username, String password) throws ClientProtocolException, IOException;

}
