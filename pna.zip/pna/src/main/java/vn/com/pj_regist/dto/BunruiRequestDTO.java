package vn.com.pj_regist.dto;

import java.util.ArrayList;

import vn.com.pj_regist.model.Bunrui;

public class BunruiRequestDTO {

	private String action;
	private ArrayList<Bunrui> deleteBunruiList;
	private ArrayList<Bunrui> addBunruiList;
	private ArrayList<Bunrui> editBunruiList;
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the deleteBunruiList
	 */
	public ArrayList<Bunrui> getDeleteBunruiList() {
		return deleteBunruiList;
	}
	/**
	 * @param deleteBunruiList the deleteBunruiList to set
	 */
	public void setDeleteBunruiList(ArrayList<Bunrui> deleteBunruiList) {
		this.deleteBunruiList = deleteBunruiList;
	}
	/**
	 * @return the addBunruiList
	 */
	public ArrayList<Bunrui> getAddBunruiList() {
		return addBunruiList;
	}
	/**
	 * @param addBunruiList the addBunruiList to set
	 */
	public void setAddBunruiList(ArrayList<Bunrui> addBunruiList) {
		this.addBunruiList = addBunruiList;
	}
	/**
	 * @return the editBunruiList
	 */
	public ArrayList<Bunrui> getEditBunruiList() {
		return editBunruiList;
	}
	/**
	 * @param editBunruiList the editBunruiList to set
	 */
	public void setEditBunruiList(ArrayList<Bunrui> editBunruiList) {
		this.editBunruiList = editBunruiList;
	}
	
}
