package vn.com.pj_regist.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.client.ClientProtocolException;

import vn.com.pj_regist.api.WebTSClient;
import vn.com.pj_regist.config.Constants;

public class LoginServiceImpl implements LoginService{

	/**
	 * Call the WebTS API to login
	 * @return
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	@Override
	public String doLogin(String username, String password) throws ClientProtocolException, IOException {
		Map<String,String> map = new HashMap<String,String>();
		map.put("cmd", Constants.LOGIN_STRING);
		map.put("param1", username);
		map.put("param2", password);
		String result = Constants.API_CALL_ERROR;
		try {
			result = WebTSClient.doGet(map).get("status").toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
