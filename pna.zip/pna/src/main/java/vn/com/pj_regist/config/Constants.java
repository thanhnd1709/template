package vn.com.pj_regist.config;

public class Constants {
	
	public static final String ACTION_REGISTER = "register";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_LIST = "list";
	public static final String ACTION_EDIT = "edit";
	public static final String ACTION_SEARCH = "search";
	public static final String ACTION_SAVE = "save";
	
	public static final String LOGIN_STRING = "login";
	public static final String ADD_PROJECT = "add_project";
	public static final String EDIT_PROJECT = "edit_project";
	public static final String DELETE_PROJECT = "del_project";
	public static final String LOGIN_SUCCESS = "0";
	public static final String LOGIN_AUTHENTICATE_FAILURE = "2";
	public static final String LOGIN_NO_USER_RIGHT = "3";
	
	public static final String API_CALL_ERROR = "999";
	public static final String NETWORK_CONNECTION_ERROR = "001";
	public static final String DUPLICATE_PROJECT_ERROR = "150";
	public static final String UPDATE_NOT_FOUND_ERROR = "160";
	public static final String DELETE_NOT_FOUND_ERROR = "170";
	public static final String NO_DELETION_TARGET_ERROR = "180";
	
	public static final String SUCCESSFUL_STATUS = "0";
	
	public static final int MAX_INTERVAL = 15*60;
}
