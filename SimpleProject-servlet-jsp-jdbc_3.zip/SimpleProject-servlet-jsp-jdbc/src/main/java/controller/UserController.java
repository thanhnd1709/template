package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import persistence.UserDAO;

@WebServlet("/userController.do")
public class UserController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String action = req.getParameter("action");
		
		if(action != null){
			if(action.equals("delete")){
				delete(req, resp);
			}else if(action.equals("list")){
				list(req, resp);
			}else if(action.equals("alter")){
				alter(req, resp);
			}else if(action.equals("insert")){
				insert(req, resp);
			}
		}else{
			resp.sendRedirect("userController.do?action=list");
		}
	}


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String surname = req.getParameter("surname");
		String login = req.getParameter("login");
		String password = req.getParameter("password");
		
		User user = new User();
		if(id != null && !id.equals("null")){
			user.setId(Integer.parseInt(id));
		}
		user.setName(name);
		user.setSurname(surname);
		user.setLogin(login);
		user.setPassword(password);
		
		UserDAO userDAO = new UserDAO();
		try {
			userDAO.register(user);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		resp.sendRedirect("userController.do?action=list");
	}
	
	private void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		String id = req.getParameter("id");
		User user = new User();
		if (id != null && !id.isEmpty()) {
			user.setId(Integer.parseInt(id));
		}

		UserDAO userDAO = new UserDAO();
		try {
			userDAO.delete(user);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		resp.sendRedirect("userController.do?action=list");
	}

	private void list(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		UserDAO userDAO = new UserDAO();
		List<User> users = new ArrayList<User>();
		
		users = userDAO.list();

		req.setAttribute("users", users);
		req.getRequestDispatcher("jsp/listUsers.jsp").forward(req, resp);
	}

	private void alter(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String id = req.getParameter("id");
		User user = new User();
		if(id != null && !id.isEmpty()){
			user.setId(Integer.parseInt(id));
		}else{
			resp.sendRedirect("userController.do?action=list");
		}
		
		UserDAO userDAO = new UserDAO();
		
		user = userDAO.searchFor(user);
		if(user != null){
			req.setAttribute("user", user);
			req.getRequestDispatcher("jsp/formRegistration.jsp").forward(req, resp);
			return;
		}
		resp.sendRedirect("userController.do?action=list");
	}
	private void insert(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = new User();
		req.setAttribute("user", user);
		req.getRequestDispatcher("jsp/formRegistration.jsp").forward(req, resp);
	}
}
