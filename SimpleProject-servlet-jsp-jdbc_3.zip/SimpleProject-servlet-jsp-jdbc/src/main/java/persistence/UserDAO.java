package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import config.ConnectionFactory;
import model.User;

public class UserDAO {

	private Connection connection = ConnectionFactory.getConnection();

	public void register(User user) throws SQLException{
		if(user != null && user.getId() != null){
			alter(user);
		}else{
			insert(user);
		}
	}
	
	public void insert(User user) throws SQLException {
		String sql = "insert into users (name, surname, login, password) values (?, ?, ?, ?)";
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, user.getName());
			statement.setString(2, user.getSurname());
			statement.setString(3, user.getLogin());
			statement.setString(4, user.getPassword());

			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void alter(User user) throws SQLException {
		String sql = "update users set name = ?,  surname = ?, login = ?, password = ? where id = ?";
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, user.getName());
			statement.setString(2, user.getSurname());
			statement.setString(3, user.getLogin());
			statement.setString(4, user.getPassword());
			statement.setInt(5, user.getId());

			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void delete(User user) throws SQLException {
		String sql = "delete from users where id = ?";
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, user.getId());

			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<User> list() {
        List<User> lista = new ArrayList<User>();
        ResultSet rs;
        PreparedStatement statement = null;
        try {
            String sql = "select * from users order by id";
            statement = connection.prepareStatement(sql);
            
            rs = statement.executeQuery();
            while (rs.next()) {

                User user = new User();
                user.setName(rs.getString("name"));
                user.setSurname(rs.getString("surname"));
                user.setLogin(rs.getString("login"));
                user.setPassword(rs.getString("password"));
                user.setId(rs.getInt("id"));
                lista.add(user);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
//        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return lista;
    }
	
	public User searchFor(User usu) {
        ResultSet rs;
        PreparedStatement statement = null;
        User user = null;
        try {
            String sql = "select * from users where id = ?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, usu.getId());
            rs = statement.executeQuery();
            if(rs.next()) {

                user = new User();
                user.setName(rs.getString("name"));
                user.setSurname(rs.getString("surname"));
                user.setLogin(rs.getString("login"));
                user.setPassword(rs.getString("password"));
                user.setId(rs.getInt("id"));

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
//        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return user;
    }

}
