package vn.com.kaopiz.pj_regist.config;

import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.Connection;

public class ConnectionFactory {

	private static final String URL = "jdbc:postgresql://localhost:5432/estudando?currentSchema=estudando";
	private static final String USER = "postgres";
	private static final String PASSWORD = "123456";
	private static final String DRIVER = "org.postgresql.Driver";

	public static Connection getConnection() {
		try {
			Class.forName(DRIVER);
			return DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

}
