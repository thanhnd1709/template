package vn.com.kaopiz.pj_regist.service;

import java.sql.SQLException;
import java.util.List;

import vn.com.kaopiz.pj_regist.model.Project;

public interface ProjectService {
	/**
	 * insert new project
	 * @param project
	 * @throws SQLException 
	 */
	public int insert(Project project) throws SQLException;
	
	/**
	 * update current project
	 * @param project
	 * @throws SQLException 
	 */
	public int update(Project project) throws SQLException;
	
	/**
	 * delete project
	 * @param project
	 */
	public int delete(Project project) throws SQLException;
	
	/**
	 * get all project
	 * @return
	 */
	public List<Project> getAllProjects() throws SQLException;
	
	/**
	 * get by id
	 * @return
	 */
	public Project getById(int id) throws SQLException;

}
