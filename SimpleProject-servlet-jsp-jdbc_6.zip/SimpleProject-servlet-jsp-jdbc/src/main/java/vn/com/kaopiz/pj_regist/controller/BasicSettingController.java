package vn.com.kaopiz.pj_regist.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import vn.com.kaopiz.pj_regist.config.Constants;
import vn.com.kaopiz.pj_regist.dto.BasicSettingRequestDTO;
import vn.com.kaopiz.pj_regist.dto.ResponseDTO;
import vn.com.kaopiz.pj_regist.persistence.BasicSettingDAO;
import vn.com.kaopiz.pj_regist.service.BasicSettingService;
import vn.com.kaopiz.pj_regist.service.BasicSettingServiceImpl;

@WebServlet("/basicSettingController.do")
public class BasicSettingController extends BaseController {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Getting the json content
		Gson gson = new Gson();
		String basicSettingJsonString = getReqestBody(req);
		BasicSettingRequestDTO basicSettingDTO = gson.fromJson(basicSettingJsonString, BasicSettingRequestDTO.class);
		// Initializing service
		BasicSettingService basicSettingService = new BasicSettingServiceImpl(new BasicSettingDAO());
		try {
			String param = "";
			if (Constants.ACTION_REGISTER.equals(basicSettingDTO.getAction())) {
				param = basicSettingService.insert(basicSettingDTO.getBasicSetting()) +"";
			} else if (Constants.ACTION_EDIT.equals(basicSettingDTO.getAction())){
				param = basicSettingService.update(basicSettingDTO.getBasicSetting()) +"";
			} else if (Constants.ACTION_LIST.equals(basicSettingDTO.getAction())){
				param = gson.toJson(basicSettingService.getAllBasicSettings());
			} else if (Constants.ACTION_DELETE.equals(basicSettingDTO.getAction())){
				param = basicSettingService.delete(basicSettingDTO.getBasicSetting()) +"";
			} else {
				throw new Exception("Action not supported");
			}
			ResponseDTO successResponse = new ResponseDTO();
			successResponse.setResult(ResponseDTO.ResponseResult.OK);
			successResponse.setParameter(param);
			sendResponse(resp, successResponse);
			
		} catch (Exception exception) {
			ResponseDTO errorResponse = new ResponseDTO();
			errorResponse.setErrorMessage(exception.getMessage());
			errorResponse.setResult(ResponseDTO.ResponseResult.NG);
			sendResponse(resp, errorResponse);
			exception.printStackTrace();
		}
		
	}
}
