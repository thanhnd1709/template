package vn.com.kaopiz.pj_regist.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import vn.com.kaopiz.pj_regist.config.Constants;
import vn.com.kaopiz.pj_regist.dto.BunruiRequestDTO;
import vn.com.kaopiz.pj_regist.dto.ResponseDTO;
import vn.com.kaopiz.pj_regist.persistence.BunruiDAO;
import vn.com.kaopiz.pj_regist.service.BunruiService;
import vn.com.kaopiz.pj_regist.service.BunruiServiceImpl;

@WebServlet("/bunruiController.do")
public class BunruiController extends BaseController {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Getting the json content
		Gson gson = new Gson();
		String bunruiJsonString = getReqestBody(req);
		BunruiRequestDTO bunruiDTO = gson.fromJson(bunruiJsonString, BunruiRequestDTO.class);
		// Initializing service
		BunruiService bunruiService = new BunruiServiceImpl(new BunruiDAO());
		try {
			String param = "";
			if (Constants.ACTION_REGISTER.equals(bunruiDTO.getAction())) {
				param = bunruiService.insert(bunruiDTO.getBunrui()) +"";
			} else if (Constants.ACTION_EDIT.equals(bunruiDTO.getAction())){
				param = bunruiService.update(bunruiDTO.getBunrui()) +"";
			} else if (Constants.ACTION_LIST.equals(bunruiDTO.getAction())){
				param = gson.toJson(bunruiService.getAllBunruis());
			} else if (Constants.ACTION_DELETE.equals(bunruiDTO.getAction())){
				param = bunruiService.delete(bunruiDTO.getBunrui()) +"";
			} else {
				throw new Exception("Action not supported");
			}
			ResponseDTO successResponse = new ResponseDTO();
			successResponse.setResult(ResponseDTO.ResponseResult.OK);
			successResponse.setParameter(param);
			sendResponse(resp, successResponse);
			
		} catch (Exception exception) {
			ResponseDTO errorResponse = new ResponseDTO();
			errorResponse.setErrorMessage(exception.getMessage());
			errorResponse.setResult(ResponseDTO.ResponseResult.NG);
			sendResponse(resp, errorResponse);
			exception.printStackTrace();
		}
		
	}
}
