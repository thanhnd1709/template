package vn.com.kaopiz.pj_regist.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import vn.com.kaopiz.pj_regist.config.Constants;
import vn.com.kaopiz.pj_regist.dto.ProjectRequestDTO;
import vn.com.kaopiz.pj_regist.dto.ResponseDTO;
import vn.com.kaopiz.pj_regist.persistence.ProjectDAO;
import vn.com.kaopiz.pj_regist.service.ProjectService;
import vn.com.kaopiz.pj_regist.service.ProjectServiceImpl;

@WebServlet("/projectController.do")
public class ProjectController extends BaseController {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Getting the json content
		Gson gson = new Gson();
		String projectJsonString = getReqestBody(req);
		ProjectRequestDTO projectDTO = gson.fromJson(projectJsonString, ProjectRequestDTO.class);
		// Initializing service
		ProjectService projectService = new ProjectServiceImpl(new ProjectDAO());
		try {
			String param = "";
			if (Constants.ACTION_REGISTER.equals(projectDTO.getAction())) {
				param = projectService.insert(projectDTO.getProject()) +"";
			} else if (Constants.ACTION_EDIT.equals(projectDTO.getAction())){
				param = projectService.update(projectDTO.getProject()) +"";
			} else if (Constants.ACTION_LIST.equals(projectDTO.getAction())){
				param = gson.toJson(projectService.getAllProjects());
			} else if (Constants.ACTION_DELETE.equals(projectDTO.getAction())){
				param = projectService.delete(projectDTO.getProject()) +"";
			} else {
				throw new Exception("Action not supported");
			}
			ResponseDTO successResponse = new ResponseDTO();
			successResponse.setResult(ResponseDTO.ResponseResult.OK);
			successResponse.setParameter(param);
			sendResponse(resp, successResponse);
			
		} catch (Exception exception) {
			ResponseDTO errorResponse = new ResponseDTO();
			errorResponse.setErrorMessage(exception.getMessage());
			errorResponse.setResult(ResponseDTO.ResponseResult.NG);
			sendResponse(resp, errorResponse);
			exception.printStackTrace();
		}
		
	}
}
