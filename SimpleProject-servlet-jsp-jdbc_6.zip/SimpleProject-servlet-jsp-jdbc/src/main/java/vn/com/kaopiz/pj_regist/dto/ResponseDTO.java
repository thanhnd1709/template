package vn.com.kaopiz.pj_regist.dto;

public class ResponseDTO {
	
	public enum ResponseResult 
	{
		NG,
		OK
	}
	
	private ResponseResult result;
	
	private String errorMessage;
	
	private String parameter;

	public ResponseResult getResult() {
		return result;
	}

	public void setResult(ResponseResult result) {
		this.result = result;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

}
