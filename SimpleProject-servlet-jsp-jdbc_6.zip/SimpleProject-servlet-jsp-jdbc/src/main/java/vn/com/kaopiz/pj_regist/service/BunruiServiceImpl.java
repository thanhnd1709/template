package vn.com.kaopiz.pj_regist.service;

import java.sql.SQLException;
import java.util.List;
import vn.com.kaopiz.pj_regist.model.Bunrui;
import vn.com.kaopiz.pj_regist.persistence.BunruiDAO;

public class BunruiServiceImpl  implements BunruiService{

	private BunruiDAO bunruiDAO;
	public BunruiServiceImpl(BunruiDAO bunruiDAO) {
		this.bunruiDAO = bunruiDAO;
	}
	/**
	 * @return the bunruiDAO
	 */
	public BunruiServiceImpl() {
	}
	/**
	 * @return the bunruiDAO
	 */
	public BunruiDAO getBunruiDAO() {
		return bunruiDAO;
	}
	/**
	 * @param bunruiDAO the bunruiDAO to set
	 */
	public void setBunruiDAO(BunruiDAO bunruiDAO) {
		this.bunruiDAO = bunruiDAO;
	}
	@Override
	public int insert(Bunrui bunrui) throws SQLException {
		bunruiDAO.insert(bunrui);
		return bunrui.getId();
	}
	@Override
	public int update(Bunrui bunrui) throws SQLException {
		bunruiDAO.update(bunrui);
		return bunrui.getId();
	}
	@Override
	public int delete(Bunrui bunrui) throws SQLException{
		bunruiDAO.delete(bunrui);
		return bunrui.getId();
	}
	@Override
	public List<Bunrui> getAllBunruis() throws SQLException{
		return bunruiDAO.getAllBunruis();
	}
	@Override
	public Bunrui getById(int id) throws SQLException {
		return bunruiDAO.getById(id);
	}

}
