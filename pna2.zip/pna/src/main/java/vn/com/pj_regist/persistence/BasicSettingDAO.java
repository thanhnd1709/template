package vn.com.pj_regist.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.pj_regist.config.ConnectionFactory;
import vn.com.pj_regist.model.BasicSetting;

public class BasicSettingDAO {

private Connection connection = ConnectionFactory.getConnection();

	/**
	 * Insert new basicSetting
	 * @param basicSetting
	 */
	public void insert(BasicSetting basicSetting) {
		String sql = "insert into m_basic_setting ("
				+ "id, "
				+ "bunrui_max, "
				+ "project_digit, "
				+ "project_min, "
				+ "sub_digit, "
				+ "sub_min ) values (?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, basicSetting.getId());
			statement.setInt(2, basicSetting.getBunruiMax());
			statement.setInt(3, basicSetting.getProjectDigit());
			statement.setInt(4, basicSetting.getProjectMin());
			statement.setInt(5, basicSetting.getSubDigit());
			statement.setInt(6, basicSetting.getSubMin());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Modify existing basicSetting
	 * @param basicSetting
	 * @throws SQLException
	 */
	public void update(BasicSetting basicSetting) throws SQLException {
		String sql = "update m_basic_setting set "
				+ "bunrui_max = ?, "
				+ "project_digit = ?, "
				+ "project_min = ?, "
				+ "sub_digit = ?, "
				+ "sub_min = ? "
				+ "where id = ?";
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, basicSetting.getBunruiMax());
			statement.setInt(2, basicSetting.getProjectDigit());
			statement.setInt(3, basicSetting.getProjectMin());
			statement.setInt(4, basicSetting.getSubDigit());
			statement.setInt(5, basicSetting.getSubMin());
			statement.setInt(6, basicSetting.getId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Deleting basicSetting
	 * @param basicSetting
	 * @throws SQLException
	 */
	public void delete(BasicSetting basicSetting) throws SQLException {
		String sql = "delete from m_basic_setting where id = ?";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, basicSetting.getId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Getting all basic setting
	 * @return
	 */
	public List<BasicSetting> getAllBasicSettings() {
		List<BasicSetting> basicSettingList = new ArrayList<BasicSetting>();
        ResultSet rs;
        PreparedStatement statement = null;
        try {
            String sql = "select * from m_basic_setting order by id";
            statement = connection.prepareStatement(sql);
            rs = statement.executeQuery();
            while (rs.next()) {
            	BasicSetting tempBasicSetting = new BasicSetting();
            	tempBasicSetting.setId(Integer.parseInt(rs.getString("id")));
            	tempBasicSetting.setBunruiMax(Integer.parseInt(rs.getString("bunrui_max")));
            	tempBasicSetting.setProjectDigit(Integer.parseInt(rs.getString("project_digit")));
            	tempBasicSetting.setProjectMin(Integer.parseInt(rs.getString("project_min")));
            	tempBasicSetting.setSubDigit(Integer.parseInt(rs.getString("sub_digit")));
            	tempBasicSetting.setSubMin(Integer.parseInt(rs.getString("sub_min")));
                basicSettingList.add(tempBasicSetting);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return basicSettingList;
	}

	/**
	 * Getting basic setting by ID
	 * @return
	 */
	public BasicSetting getById(int id) {
		ResultSet rs;
        PreparedStatement statement = null;
        BasicSetting tempBasicSetting = null;
        try {
            String sql = "select * from m_basic_setting where id = ?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            rs = statement.executeQuery();
            if(rs.next()) {
            	tempBasicSetting = new BasicSetting();
            	tempBasicSetting.setId(Integer.parseInt(rs.getString("id")));
            	tempBasicSetting.setBunruiMax(Integer.parseInt(rs.getString("bunrui_max")));
            	tempBasicSetting.setProjectDigit(Integer.parseInt(rs.getString("project_digit")));
            	tempBasicSetting.setProjectMin(Integer.parseInt(rs.getString("project_min")));
            	tempBasicSetting.setSubDigit(Integer.parseInt(rs.getString("sub_digit")));
            	tempBasicSetting.setSubMin(Integer.parseInt(rs.getString("sub_min")));

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return tempBasicSetting;
	}

}
