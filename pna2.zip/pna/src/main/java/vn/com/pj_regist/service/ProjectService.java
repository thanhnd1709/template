package vn.com.pj_regist.service;

import java.sql.SQLException;
import java.util.List;

import vn.com.pj_regist.dto.ProjectRequestDTO;
import vn.com.pj_regist.model.Project;

public interface ProjectService {
	/**
	 * insert new project
	 * @param project
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public int insert(ProjectRequestDTO project) throws SQLException, Exception;
	
	/**
	 * update current project
	 * @param project
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public int update(ProjectRequestDTO project) throws SQLException, Exception;
	
	/**
	 * delete project
	 * @param project
	 * @throws Exception 
	 */
	public int delete(ProjectRequestDTO project) throws SQLException, Exception;
	
	/**
	 * get all project
	 * @return
	 */
	public List<Project> getAllProjects() throws SQLException;
	
	/**
	 * get by id
	 * @return
	 */
	public Project getById(int id) throws SQLException;
	
	/**
	 * 
	 * @param project
	 * @return
	 * @throws SQLException
	 */
	public List<Project> searchProject(Project project) throws SQLException; 

}
