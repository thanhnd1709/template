package vn.com.pj_regist.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import vn.com.pj_regist.config.Constants;
import vn.com.pj_regist.dto.ProjectRequestDTO;
import vn.com.pj_regist.dto.ResponseDTO;
import vn.com.pj_regist.persistence.ProjectDAO;
import vn.com.pj_regist.service.ProjectService;
import vn.com.pj_regist.service.ProjectServiceImpl;

@WebServlet("/project")
public class ProjectController extends BaseController {

	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("user") == null) {   //checking whether the session exists
        	RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/jsp/login.jsp");
        	dispatcher.forward(req,res);
        } else {
            // pass the request along the filter chain
        	RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/jsp/project.jsp");
        	dispatcher.forward(req,res);
        }
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Getting the json content
		Gson gson = new Gson();
		String projectJsonString = getReqestBody(req);
		ProjectRequestDTO projectDTO = gson.fromJson(projectJsonString, ProjectRequestDTO.class);
		// Initializing service
		ProjectService projectService = new ProjectServiceImpl(new ProjectDAO());
		try {
			String param = "";
			if (Constants.ACTION_REGISTER.equals(projectDTO.getAction())) {
				param = projectService.insert(projectDTO) +"";
			} else if (Constants.ACTION_EDIT.equals(projectDTO.getAction())){
				param = projectService.update(projectDTO) +"";
			} else if (Constants.ACTION_LIST.equals(projectDTO.getAction())){
				param = gson.toJson(projectService.getAllProjects());
			} else if (Constants.ACTION_DELETE.equals(projectDTO.getAction())){
				param = projectService.delete(projectDTO) +"";
			} else if (Constants.ACTION_SEARCH.equals(projectDTO.getAction())){
				param = gson.toJson(projectService.searchProject(projectDTO.getProject())) +"";
			} else {
				throw new Exception("Action not supported");
			}
			ResponseDTO successResponse = new ResponseDTO();
			successResponse.setResult(ResponseDTO.ResponseResult.OK);
			successResponse.setParameter(param);
			sendResponse(resp, successResponse);
			
		} catch (Exception exception) {
			ResponseDTO errorResponse = new ResponseDTO();
			errorResponse.setErrorMessage(exception.getMessage());
			errorResponse.setResult(ResponseDTO.ResponseResult.NG);
			sendResponse(resp, errorResponse);
			exception.printStackTrace();
		}
		
	}
}
