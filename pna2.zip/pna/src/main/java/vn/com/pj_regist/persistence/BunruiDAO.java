package vn.com.pj_regist.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.com.pj_regist.config.ConnectionFactory;
import vn.com.pj_regist.config.Utils;
import vn.com.pj_regist.dto.BunruiRequestDTO;
import vn.com.pj_regist.model.Bunrui;

public class BunruiDAO {

private Connection connection = ConnectionFactory.getConnection();

	/**
	 * Insert new bunrui
	 * @param bunrui
	 */
	public void insert(Bunrui bunrui) throws SQLException{
		String sql = "insert into bunrui_table ("
				+ "bunrui_id, "
				+ "bunrui, "
				+ "type, "
				+ "comment, "
				+ "sort_order ) values (?, ?, ?, ?, ? )";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, bunrui.getId());
			statement.setString(2, bunrui.getBunrui());
			statement.setInt(3, bunrui.getType());
			statement.setString(4, bunrui.getComment());
			statement.setInt(5, bunrui.getSortOrder());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				//connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Modify existing bunrui
	 * @param bunrui
	 * @throws SQLException
	 */
	public void update(Bunrui bunrui) throws SQLException {
		String sql = "update bunrui_table set ";
		
		sql += ((!Utils.isEmptyString(bunrui.getBunrui()))?"bunrui = ?, ":"");
		sql += ((bunrui.getType() != 0)?"type = ?, ":"");
		sql += ((!Utils.isEmptyString(bunrui.getComment()))?"comment = ?, ":"");
		sql += ((bunrui.getSortOrder() != 0)?"sort_order = ?, ":"");
		sql = sql.substring(0, sql.length() - 2);
		sql += (" where bunrui_id = ?");
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			int i =1;
			if (!Utils.isEmptyString(bunrui.getBunrui())) {
				statement.setString(i, bunrui.getBunrui());
				i ++;
			}
			if (bunrui.getType() != 0) {
				statement.setInt(i, bunrui.getType());
				i ++;
			}
			if (!Utils.isEmptyString(bunrui.getComment())) {
				statement.setString(i, bunrui.getComment());
				i ++;
			}
			if (bunrui.getSortOrder() != 0) {
				statement.setInt(i, bunrui.getSortOrder());
				i ++;
			}
			statement.setInt(i, bunrui.getId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				//connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Deleting bunrui
	 * @param bunrui
	 * @throws SQLException
	 */
	public void delete(Bunrui bunrui) throws SQLException {
		String sql = "delete from bunrui_table where bunrui_id = ?";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, bunrui.getId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				//connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Getting all bunrui
	 * @return
	 */
	public List<Bunrui> getAllBunruis() throws SQLException{
		List<Bunrui> bunruiList = new ArrayList<Bunrui>();
        ResultSet rs;
        PreparedStatement statement = null;
        try {
            String sql = "select * from bunrui_table order by sort_order";
            statement = connection.prepareStatement(sql);
            rs = statement.executeQuery();
            while (rs.next()) {
            	Bunrui tempBunrui = new Bunrui();
            	tempBunrui.setId(Integer.parseInt(rs.getString("bunrui_id")));
            	tempBunrui.setBunrui(rs.getString("bunrui"));
            	tempBunrui.setType(Integer.parseInt(rs.getString("type")));
            	tempBunrui.setComment(rs.getString("comment"));
            	tempBunrui.setSortOrder(Integer.parseInt(rs.getString("sort_order")));
                bunruiList.add(tempBunrui);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return bunruiList;
	}

	/**
	 * Get Bunrui by bunrui id
	 * @param id
	 * @return
	 */
	public Bunrui getById(int id) {
		ResultSet rs;
        PreparedStatement statement = null;
        Bunrui tempBunrui = null;
        try {
            String sql = "select * from bunrui_table where bunrui_id = ?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            rs = statement.executeQuery();
            if(rs.next()) {
            	tempBunrui = new Bunrui();
            	tempBunrui.setId(Integer.parseInt(rs.getString("bunrui_id")));
            	tempBunrui.setBunrui(rs.getString("bunrui"));
            	tempBunrui.setType(Integer.parseInt(rs.getString("type")));
            	tempBunrui.setComment(rs.getString("comment"));
            	tempBunrui.setSortOrder(Integer.parseInt(rs.getString("sort_order")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return tempBunrui;
	}

	public void save(BunruiRequestDTO bunruiDTO) throws SQLException  {
		try {
			connection.setAutoCommit(false);
			for (int i = 0; i < bunruiDTO.getDeleteBunruiList().size(); i++ ) {
				this.delete(bunruiDTO.getDeleteBunruiList().get(i));
			}
			for (int i = 0; i < bunruiDTO.getAddBunruiList().size(); i++ ) {
				this.insert(bunruiDTO.getAddBunruiList().get(i));
			}
			for (int i = 0; i < bunruiDTO.getEditBunruiList().size(); i++ ) {
				this.update(bunruiDTO.getEditBunruiList().get(i));
			}
			connection.commit();
		} catch (SQLException ex) {
			ex.printStackTrace();
			connection.rollback();
		} finally {
			connection.close();
		}
	}

}
