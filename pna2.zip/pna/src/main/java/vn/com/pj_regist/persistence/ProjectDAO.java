package vn.com.pj_regist.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vn.com.pj_regist.config.ConnectionFactory;
import vn.com.pj_regist.config.Utils;
import vn.com.pj_regist.model.Project;

public class ProjectDAO {
	
	private Connection connection = ConnectionFactory.getConnection();
	
	/**
	 * Insert new project
	 * @param project
	 */
	public int insert(Project project) throws SQLException {
		String sql = "insert into t_project ("
				//+ "project_id, "
				+ "bunrui_id, "
				+ "project_no, "
				+ "sub_code, "
				+ "project_name, "
				+ "sub_name, "
				+ "project_leader, "
				+ "project_leader_name, "
				+ "webts_pj_id ) values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			//statement.setInt(1, project.getProjectId());
			statement.setInt(1, project.getBunruiId());
			statement.setInt(2, project.getProjectNo());
			statement.setInt(3, project.getSubCode());
			statement.setString(4, project.getProjectName());
			statement.setString(5, project.getSubName());
			statement.setInt(6, project.getProjectLeader());
			statement.setString(7, project.getProjectLeaderName());
			statement.setInt(8, project.getWebTSPjId());
			//statement.execute();
			// Get generated key
			int affectedRows = statement.executeUpdate();
	        if (affectedRows == 0) {
	            throw new SQLException("Creating user failed, no rows affected.");
	        }
	        try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
	            if (generatedKeys.next()) {
	            	project.setProjectId((int) generatedKeys.getLong(1));
	            }
	            else {
	                throw new SQLException("Creating user failed, no ID obtained.");
	            }
	        }
			// End get generated key
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				//connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return project.getProjectId();
	}

	/**
	 * Modify existing project
	 * @param project
	 * @throws SQLException
	 */
	public void update(Project project) throws SQLException {
		String sql = "update t_project set "
				+ "bunrui_id = ?,  "
				+ "project_no = ?, "
				+ "sub_code = ?, "
				+ "project_name = ?, "
				+ "sub_name = ?, "
				+ "project_leader = ?, "
				+ "project_leader_name = ?, "
				+ "webts_pj_id = ? "
				+ "where project_id = ?";
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, project.getBunruiId());
			statement.setInt(2, project.getProjectNo());
			statement.setInt(3, project.getSubCode());
			statement.setString(4, project.getProjectName());
			statement.setString(5, project.getSubName());
			statement.setInt(6, project.getProjectLeader());
			statement.setString(7, project.getProjectLeaderName());
			statement.setInt(8, project.getWebTSPjId());
			statement.setInt(9, project.getProjectId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Deleting project
	 * @param project
	 * @throws SQLException
	 */
	public void delete(Project project) throws SQLException {
		String sql = "delete from t_project where project_id = ?";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, project.getProjectId());
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Getting all projects
	 * @return
	 */
	public List<Project> getAllProjects() {
		List<Project> projectList = new ArrayList<Project>();
        ResultSet rs;
        PreparedStatement statement = null;
        try {
        	String sql = "select t_project.*, bunrui_table.bunrui, bunrui_table.sort_order from t_project "
            		+ "inner join bunrui_table on "
            		+ "t_project.bunrui_id = bunrui_table.bunrui_id "
        			+ "order by bunrui_table.sort_order ASC, t_project.project_no DESC, t_project.sub_code DESC ";
            statement = connection.prepareStatement(sql);
            rs = statement.executeQuery();
            while (rs.next()) {
            	Project tempProject = new Project();
            	tempProject.setProjectId(Integer.parseInt(rs.getString("project_id")));
            	tempProject.setBunruiId(Integer.parseInt(rs.getString("bunrui_id")));
            	tempProject.setBunrui(rs.getString("bunrui"));
            	tempProject.setProjectNo(Integer.parseInt(rs.getString("project_no")));
            	tempProject.setSubCode(Integer.parseInt(rs.getString("sub_code")));
            	tempProject.setProjectName(rs.getString("project_name"));
            	tempProject.setSubName(rs.getString("sub_name"));
            	tempProject.setProjectLeaderName(rs.getString("project_leader_name"));
            	tempProject.setProjectLeader(Integer.parseInt(rs.getString("project_leader")));
            	tempProject.setWebTSPjId(Integer.parseInt(rs.getString("webts_pj_id")));
                projectList.add(tempProject);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return projectList;
	}

	/**
	 * Get project by ID
	 * @param id
	 * @return
	 */
	public Project getById(int id) {
		ResultSet rs;
        PreparedStatement statement = null;
        Project tempProject = null;
        try {
            String sql = "select * from t_project where id = ?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            rs = statement.executeQuery();
            if(rs.next()) {
            	tempProject = new Project();
            	tempProject.setProjectId(Integer.parseInt(rs.getString("project_id")));
            	tempProject.setBunruiId(Integer.parseInt(rs.getString("bunrui_id")));
            	tempProject.setProjectNo(Integer.parseInt(rs.getString("project_no")));
            	tempProject.setSubCode(Integer.parseInt(rs.getString("sub_code")));
            	tempProject.setProjectName(rs.getString("project_name"));
            	tempProject.setSubName(rs.getString("sub_name"));
            	tempProject.setProjectLeaderName(rs.getString("project_leader"));
            	tempProject.setProjectLeader(Integer.parseInt(rs.getString("project_leader_name")));
            	tempProject.setWebTSPjId(Integer.parseInt(rs.getString("webts_pj_id")));

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return tempProject;
	}

	/**
	 * search project
	 * @param project
	 * @return
	 */
	public List<Project> searchProject(Project project) {
		List<Project> projectList = new ArrayList<Project>();
        ResultSet rs;
        StringBuilder str = new StringBuilder("select t_project.*, bunrui_table.bunrui, bunrui_table.sort_order  from t_project "
        		+ "inner join bunrui_table on "
        		+ "t_project.bunrui_id = bunrui_table.bunrui_id "
        		+ "where ");
        str.append((project.getBunruiId() != 0)?"t_project.bunrui_id = ? and ":"");
        str.append((project.getProjectNo() != 0)?"t_project.project_no = ? and ":"");
        str.append((project.getSubCode() != 0)?"t_project.sub_code = ? and ":"");
        str.append(!Utils.isEmptyString(project.getProjectName())?"lower(t_project.project_name) like ? and ":"");
        str.append(!Utils.isEmptyString(project.getSubName())?"lower(t_project.sub_name) like ? and ":"");
        str.append(!Utils.isEmptyString(project.getProjectLeaderName())?"lower(t_project.project_leader_name) like ? and ":"");
    	str.append("1 = 1 order by bunrui_table.sort_order ASC, t_project.project_no DESC, t_project.sub_code DESC ");
        PreparedStatement statement = null;
        try {
			statement = connection.prepareStatement(str.toString());
			int i =1;
			if ((project.getBunruiId() != 0)) {
				statement.setInt(i, project.getBunruiId());
				i ++;
			}
			if ((project.getProjectNo() != 0)) {
				statement.setInt(i, project.getProjectNo());
				i ++;
			}
			if ((project.getSubCode() != 0)) {
				statement.setInt(i, project.getSubCode());
				i ++;
			}
			if (!Utils.isEmptyString(project.getProjectName())) {
				statement.setString(i, "%" + project.getProjectName() + "%");
				i ++;
			}
			if (!Utils.isEmptyString(project.getSubName())) {
				statement.setString(i, "%" + project.getSubName() + "%");
				i ++;
			}
			if (!Utils.isEmptyString(project.getProjectLeaderName())) {
				statement.setString(i, "%" + project.getProjectLeaderName() + "%");
				i ++;
			}
			statement.execute();
            rs = statement.executeQuery();
            while (rs.next()) {
            	Project tempProject = new Project();
            	tempProject.setProjectId(Integer.parseInt(rs.getString("project_id")));
            	tempProject.setBunruiId(Integer.parseInt(rs.getString("bunrui_id")));
            	tempProject.setProjectNo(Integer.parseInt(rs.getString("project_no")));
            	tempProject.setSubCode(Integer.parseInt(rs.getString("sub_code")));
            	tempProject.setProjectName(rs.getString("project_name"));
            	tempProject.setSubName(rs.getString("sub_name"));
            	tempProject.setProjectLeaderName(rs.getString("project_leader_name"));
            	tempProject.setProjectLeader(Integer.parseInt(rs.getString("project_leader")));
            	tempProject.setWebTSPjId(Integer.parseInt(rs.getString("webts_pj_id")));
            	tempProject.setBunrui(rs.getString("bunrui"));
                projectList.add(tempProject);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try {
        		statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
        return projectList;
	}

}
