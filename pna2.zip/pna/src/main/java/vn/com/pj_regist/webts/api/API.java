package vn.com.pj_regist.webts.api;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vn.com.pj_regist.controller.BaseController;

@WebServlet("/wts/api")
public class API extends BaseController{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//System.out.println(request.getParameterMap());
		String result = "";
		if (request.getParameter("cmd").toString().equals("login")) {
			if (request.getParameter("param1").toString().equals("admin") && request.getParameter("param2").toString().equals("password")) {
				result = "{\"status\":0}";
			} else if (request.getParameter("param1").toString().equals("user") && request.getParameter("param2").toString().equals("password")) {
				result = "{\"status\":3}";
			} else {
				result = "{\"status\":2}";
			}
		} else if ("get_unitlist".equals(request.getParameter("cmd").toString())) {
			result = "{ \"unit_list\": [{\"unit_id\":1,\"unit_name\":\"Dept001\"},{\"unit_id\":2,\"unit_name\":\"Dept002\"},{\"unit_id\":3,\"unit_name\":\"Dept003\"},{\"unit_id\":4,\"unit_name\":\"Dept004\"},{\"unit_id\":5,\"unit_name\":\"Dept005\"}],\"status\": 0}";
		} else if ("get_member".equals(request.getParameter("cmd").toString())) {
			result = " {\"member_list\": ["
					+ "{\"emp_no\":1,\"name\":\"member001\"},{\"emp_no\":2,\"name\":\"member002\"}, {\"emp_no\":3,\"name\":\"member003\"},{\"emp_no\":4,\"name\":\"member004\"},"
					+ "{\"emp_no\":5,\"name\":\"member005\"},{\"emp_no\":6,\"name\":\"member006\"}, {\"emp_no\":7,\"name\":\"member007\"},{\"emp_no\":8,\"name\":\"member008\"}"
					+ "],\"status\": 0}";
		} else if ("get_unit_member".equals(request.getParameter("cmd").toString())) {
			if ("1".equals(request.getParameter("param1").toString())) {
				result = " {\"member_list\": ["
						+ "{\"emp_no\":1,\"name\":\"member001\"},{\"emp_no\":2,\"name\":\"member002\"}, {\"emp_no\":3,\"name\":\"member003\"},{\"emp_no\":4,\"name\":\"member004\"}"
						+ "],\"status\": 0}";
			} else {
				result = " {\"member_list\": ["
						+ "{\"emp_no\":5,\"name\":\"member005\"},{\"emp_no\":6,\"name\":\"member006\"}, {\"emp_no\":7,\"name\":\"member007\"},{\"emp_no\":8,\"name\":\"member008\"}"
						+ "],\"status\": 0}";
			}
		} else if ("add_project".equals(request.getParameter("cmd").toString())) {
			Random r = new Random();
			int randomInt = r.nextInt(90) + 10;
			result = "{\"status\":0,"
					+ "\"project_id\":" + randomInt + "}";
		} else if ("get_pj_member".equals(request.getParameter("cmd").toString())) {
			result = " {\"member_list\": ["
					+ "{\"emp_no\":1,\"name\":\"member001\"},{\"emp_no\":2,\"name\":\"member002\"}, {\"emp_no\":3,\"name\":\"member003\"},{\"emp_no\":4,\"name\":\"member004\"}"
					+ "],\"status\": 0}";
		} else if ("edit_project".equals(request.getParameter("cmd").toString())) {
			result = "{\"status\":0}";
		} else if ("del_project".equals(request.getParameter("cmd").toString())) {
			result = "{\"status\":0}";
			//result = "{\"status\":170}";
			//result = "{\"status\":180}";
		} 
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out;
		out = response.getWriter();
		out.print(result);
	}
}
